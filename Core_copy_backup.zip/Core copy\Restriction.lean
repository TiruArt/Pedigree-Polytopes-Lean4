-- Core/Restriction.lean
import MembershipProject.Core.Basic
import MembershipProject.Core.Types
import MembershipProject.Core.Minimal

set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

namespace MembershipProject.Core

open Nat

-- ============================================
-- TRIPLE REPRESENTATION (wrapper for Node)
-- ============================================

/-- A triple (i,j,k) with constraints i < j < k -/
structure Triple where
  i : ℕ
  j : ℕ
  k : ℕ
  h_ij : i < j
  h_jk : j < k
  deriving DecidableEq, Repr

/-- Convert Triple to Node -/
def Triple.toNode (t : Triple) : Node := ⟨t.i, t.j, t.k⟩

/-- Node capacities: mapping from triples to rational values -/
structure NodeCapacities where
  caps : Triple → Rat
  nonneg : ∀ t, caps t ≥ 0

-- ============================================
-- RESTRICTION OPERATIONS
-- ============================================

namespace Restriction

/-- Generate all triples with fixed third coordinate k -/
def allTriplesWithK (k : ℕ) : Finset Triple :=
  if h : k ≥ 3 then
    ((Finset.Ico 1 k).attach.biUnion fun ⟨i, hi⟩ =>
      have hi_bound : i < k := (Finset.mem_Ico.1 hi).right
      ((Finset.Ico (i+1) k).attach.image fun ⟨j, hj⟩ =>
        have h_i_lt_j : i < j := by
          have : i + 1 ≤ j := (Finset.mem_Ico.1 hj).left
          omega
        have h_j_lt_k : j < k := (Finset.mem_Ico.1 hj).right
        Triple.mk i j k h_i_lt_j h_j_lt_k))
  else ∅

/-- Rule A: For (i, j, k), include (i, j, l) for max(j+1, 4) ≤ l < k -/
def ruleA (i j k : ℕ) (h_ij : i < j) (h_jk : j < k) : Finset Triple :=
  let lower_bound := max j 4
  let start := lower_bound + 1
  ((Finset.Ico start k).attach.image fun ⟨l, hl⟩ =>
    have mem : l ∈ Finset.Ico start k := hl
    have ⟨h_start_le_l, h_l_lt_k⟩ := Finset.mem_Ico.1 mem
    have h_j_lt_l : j < l := by
      have h_start_eq : start = max j 4 + 1 := rfl
      by_cases h : j ≥ 4
      · -- Case j ≥ 4
        have hmax : max j 4 = j := max_eq_left h
        have hstart : start = j + 1 := by rw [hmax] at h_start_eq; exact h_start_eq
        rw [hstart] at h_start_le_l
        omega
      · -- Case j < 4
        have h_j_lt_4 : j < 4 := Nat.lt_of_not_ge h
        have h_j_le_4 : j ≤ 4 := by omega
        have hmax : max j 4 = 4 := max_eq_right h_j_le_4
        have hstart : start = 5 := by rw [hmax] at h_start_eq; exact h_start_eq
        rw [hstart] at h_start_le_l
        omega
    Triple.mk i j l h_ij h_j_lt_l)

/-- Rule B: In the context of two triples (i,j,k) and (i',j',k+1),
    include (i', j', l) for max(j'+1, 4) ≤ l < k -/
def ruleB (i' j' k : ℕ) (h_i'j' : i' < j') (h_j'k : j' < k) : Finset Triple :=
  ruleA i' j' k h_i'j' h_j'k

/-- Rule C: For edge (i, j) in triple (i,j,k):
   - If j ≥ 4: Include all triples (r, s, j) with third coordinate j,
               EXCEPT those where i appears as an endpoint (r=i or s=i)
   - If j < 4: Only include the base triple (i, j, 4)

   Interpretation: This handles "flow conservation" at node j.
   When j ≥ 4, we need all edges entering/leaving layer j except those
   directly involving node i (to avoid double-counting).
   When j < 4, we're at the base case so only add the minimum required triple.
-/
def ruleC (i j : ℕ) (h_ij : i < j) : Finset Triple :=
  if h : j ≥ 4 then
    -- All triples ending at layer j, excluding those containing i
    (allTriplesWithK j).filter fun t => t.i ≠ i ∧ t.j ≠ i
  else
    -- Base case: j is in layers 1, 2, or 3
    have h_j_lt_4 : j < 4 := Nat.lt_of_not_ge h
    if h4 : j < 4 then
      {Triple.mk i j 4 h_ij (by omega)}
    else
      ∅

/-- Rule D: Same as Rule C but applied to (i', j') from the second triple (i',j',k+1)

   Interpretation: When processing two consecutive triples (i,j,k) and (i',j',k+1),
   we apply the same flow conservation rule to node j' from the second triple.
   This ensures consistency across both triples being considered for restriction.
-/
def ruleD (i' j' : ℕ) (h_i'j' : i' < j') : Finset Triple :=
  ruleC i' j' h_i'j'

/-- Compute deletion set D for two triples (i,j,k) and (i',j',k+1) -/
def computeD (t1 t2 : Triple) : Finset Triple :=
  ruleA t1.i t1.j t1.k t1.h_ij t1.h_jk ∪
  (if h : t2.j < t1.k then
     ruleB t2.i t2.j t1.k t2.h_ij h
   else ∅) ∪
  ruleC t1.i t1.j t1.h_ij ∪
  ruleD t2.i t2.j t2.h_ij

/-- Restrict capacities by zeroing out triples in deletion set D -/
def restrictCapacities (caps : NodeCapacities) (D : Finset Triple) : NodeCapacities where
  caps t := if t ∈ D then 0 else caps.caps t
  nonneg t := by
    by_cases h : t ∈ D
    · -- t is in deletion set, capacity is 0
      simp only [h, ↓reduceIte]
      norm_num
    · -- t is not in deletion set, use original non-negativity
      simp only [h, ↓reduceIte]
      exact caps.nonneg t

end Restriction

end MembershipProject.Core
