-- Core/RestrictionFull.lean
-- Complete implementation of Restricted Network N_{k-1}(L) deletion rules [a]-[g]
-- Based on Definition [Restricted Network N_{k-1}(L)]

import Mathlib.Data.Finset.Basic
import Mathlib.Tactic
import MembershipProject.Core.Basic
import MembershipProject.Core.Types

set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

namespace MembershipProject.Core

open Nat

-- ============================================
-- TRIPLE REPRESENTATION (wrapper for Node)
-- ============================================

/-- A triple (i,j,k) with constraints i < j < k -/
structure Triple where
  i : ℕ
  j : ℕ
  k : ℕ
  h_ij : i < j
  h_jk : j < k
  deriving DecidableEq, Repr

/-- Convert Triple to Node -/
def Triple.toNode (t : Triple) : Node := ⟨t.i, t.j, t.k⟩

/-- Convert Node to Triple (requires proofs of constraints) -/
def Node.toTriple (n : Node) (h_ij : n.i < n.j) (h_jk : n.j < n.k) : Triple :=
  { i := n.i, j := n.j, k := n.k, h_ij := h_ij, h_jk := h_jk }

/-- Node capacities: mapping from triples to rational values -/
structure NodeCapacities where
  caps : Triple → Rat
  nonneg : ∀ t, caps t ≥ 0

-- ============================================
-- LAYER NOTATION
-- ============================================

/-- Δ^k denotes all nodes (triples) at layer k -/
def Delta (k : ℕ) : Finset Triple :=
  if h : k ≥ 3 then
    ((Finset.Ico 1 k).attach.biUnion fun ⟨i, hi⟩ =>
      have hi_bound : i < k := (Finset.mem_Ico.1 hi).right
      ((Finset.Ico (i+1) k).attach.image fun ⟨j, hj⟩ =>
        have h_i_lt_j : i < j := by
          have : i + 1 ≤ j := (Finset.mem_Ico.1 hj).left
          omega
        have h_j_lt_k : j < k := (Finset.mem_Ico.1 hj).right
        Triple.mk i j k h_i_lt_j h_j_lt_k))
  else ∅

-- Alias for compatibility
def allTriplesWithK := Delta

-- ============================================
-- GENERATOR SETS
-- ============================================

/-- G(u) = generators of node u = {i, j, k}

    Definition: For a triangle/node u = {i, j, k}:
    - If u = {1, 2, 3}: G(u) = ∅ (root has no generators)
    - If j > 3: G(u) = {{r, i, j} : r < i} ∪ {{i, s, j} : i < s < j}
                (generators are triangles at layer j with common edge {i,j})
    - If j ≤ 3: G(u) = {{1, 2, 3}} (only generator is the root)

    Key Property: G(u = {i,j,k}) depends only on the common edge {i,j},
                  NOT on the layer k. Same generators for all k ∈ [j+1, n].

    Examples:
    - G({2, 4, 6}) = {{1, 2, 4}, {2, 3, 4}}
    - G({2, 3, 7}) = {{1, 2, 3}}
    - G({2, 4, 8}) = {{1, 2, 4}, {2, 3, 4}} (same as k=6) -/
def generators (u : Triple) : Finset Triple :=
  -- Special case: root {1, 2, 3} has no generators
  if u.i = 1 ∧ u.j = 2 ∧ u.k = 3 then
    ∅
  else if u.j > 3 then
    -- Case: j > 3, generators are triangles at layer j with common edge {i,j}
    let i := u.i
    let j := u.j

    -- Form 1: {r, i, j} where r < i
    let form1 := (Finset.Ico 1 i).attach.filterMap fun ⟨r, hr⟩ =>
      have h_r_bound : r ∈ Finset.Ico 1 i := hr
      have h_r_lt_i : r < i := (Finset.mem_Ico.1 h_r_bound).right
      if h_ij' : i < j then
        some (Triple.mk r i j h_r_lt_i h_ij')
      else none

    -- Form 2: {i, s, j} where i < s < j
    let form2 := (Finset.Ico (i+1) j).attach.filterMap fun ⟨s, hs⟩ =>
      have h_s_bound : s ∈ Finset.Ico (i+1) j := hs
      have h_s_lt_j : s < j := (Finset.mem_Ico.1 h_s_bound).right
      have h_i_lt_s : i < s := by
        have : i + 1 ≤ s := (Finset.mem_Ico.1 h_s_bound).left
        omega
      if h_sj : s < j then
        some (Triple.mk i s j u.h_ij h_sj)
      else none

    form1 ∪ form2
  else
    -- Case: j ≤ 3, only generator is {1, 2, 3}
    if h12 : 1 < 2 then
      if h23 : 2 < 3 then
        {Triple.mk 1 2 3 h12 h23}
      else ∅
    else ∅

-- ============================================
-- LINK REPRESENTATION
-- ============================================

/-- A link L = (u, v) where u = (r,s,k) and v = (i,j,k+1) -/
structure Link where
  u : Triple  -- Node at layer k
  v : Triple  -- Node at layer k+1
  h_consecutive : u.k + 1 = v.k
  deriving Repr

-- ============================================
-- DELETION RULES FOR RESTRICTED NETWORK
-- ============================================

namespace Restriction

/-- Rule (a): Include {i, j, l} in D for l ∈ [max(4, j), k-1]

    For link L = (u=(r,s,k), v=(i,j,k+1)), delete all nodes with edge (i,j)
    at layers from max(4,j) up to k-1 -/
def ruleA (link : Link) : Finset Triple :=
  let i := link.v.i
  let j := link.v.j
  let k := link.u.k
  let start := max 4 j
  ((Finset.Ico start k).attach.filterMap fun ⟨l, hl⟩ =>
    have h_l_in_range : l ∈ Finset.Ico start k := hl
    have ⟨h_start_le_l, h_l_lt_k⟩ := Finset.mem_Ico.1 h_l_in_range
    if h_ij : i < j then
      if h_jl : j < l then
        some (Triple.mk i j l h_ij h_jl)
      else none
    else none)

/-- Rule (b): Include {r, s, l} in D for l ∈ [max(4, s), k-1]

    For link L = (u=(r,s,k), v=(i,j,k+1)), delete all nodes with edge (r,s)
    at layers from max(4,s) up to k-1 -/
def ruleB (link : Link) : Finset Triple :=
  let r := link.u.i
  let s := link.u.j
  let k := link.u.k
  let start := max 4 s
  ((Finset.Ico start k).attach.filterMap fun ⟨l, hl⟩ =>
    have h_l_in_range : l ∈ Finset.Ico start k := hl
    have ⟨h_start_le_l, h_l_lt_k⟩ := Finset.mem_Ico.1 h_l_in_range
    if h_rs : r < s then
      if h_sl : s < l then
        some (Triple.mk r s l h_rs h_sl)
      else none
    else none)

/-- Rule (c): Include w ∈ Δ^s, w ∉ G(u) in D

    Delete all nodes at layer s (where s is from u=(r,s,k))
    that are NOT generators of u -/
def ruleC (link : Link) : Finset Triple :=
  let s := link.u.j
  let u := link.u
  let gens := generators u
  (Delta s).filter fun w => w ∉ gens

/-- Rule (d): Include w ∈ Δ^j, w ∉ G(v) in D

    Delete all nodes at layer j (where j is from v=(i,j,k+1))
    that are NOT generators of v -/
def ruleD (link : Link) : Finset Triple :=
  let j := link.v.j
  let v := link.v
  let gens := generators v
  (Delta j).filter fun w => w ∉ gens

/-- Rule (e): Include all nodes in Δ^k \ {u} in D

    Delete all nodes at layer k EXCEPT u itself -/
def ruleE (link : Link) : Finset Triple :=
  let k := link.u.k
  let u := link.u
  (Delta k).filter fun w => w ≠ u

/-- Rule (f): Cascading deletion of nodes with all generators deleted

    If any undeleted node {y, w, l}, l > 4 is such that all its generators
    have been deleted, include that node in D.
    Repeat until no more nodes are deleted (fixed point). -/
def ruleFStep (D : Finset Triple) (allNodes : Finset Triple) : Finset Triple :=
  allNodes.filter fun node =>
    node.k > 4 ∧
    node ∉ D ∧
    (generators node).Nonempty ∧
    (generators node) ⊆ D

/-- Compute fixed point of Rule (f) -/
def ruleF (link : Link) (D_initial : Finset Triple) (fuel : ℕ) : Finset Triple :=
  let k := link.u.k
  let allNodes := (Finset.range (k + 1)).biUnion fun l => Delta l
  match fuel with
  | 0 => ∅
  | fuel' + 1 =>
    let newDeleted := ruleFStep D_initial allNodes
    if newDeleted.Nonempty then
      ruleF link (D_initial ∪ newDeleted) fuel'
    else
      ∅

-- ============================================
-- RIGID PEDIGREE DELETION
-- ============================================

/-- A rigid pedigree at layer l -/
structure RigidPedigree (l : ℕ) where
  nodes : List Triple
  flow : Rat
  deriving Repr

/-- Rule (g): Delete rigid pedigrees containing deleted nodes

    If a node from D appears in any rigid pedigree, that pedigree is deleted.
    This means corresponding shrunk nodes are deleted from the network. -/
def ruleG (link : Link) (D : Finset Triple)
    (rigidPedigrees : List (RigidPedigree link.u.k)) : Finset Triple :=
  let affectedPedigrees := rigidPedigrees.filter fun P =>
    P.nodes.any fun node => node ∈ D
  -- Convert affected pedigrees to set of nodes to delete
  -- (Implementation depends on how shrunk nodes are represented)
  affectedPedigrees.foldl (fun acc P =>
    acc ∪ P.nodes.toFinset) ∅

-- ============================================
-- COMPLETE DELETION SET COMPUTATION
-- ============================================

/-- Compute complete deletion set D for restricted network N_{k-1}(L)

    Given k ∈ [5, n-1] and link L = (u={r,s,k}, v={i,j,k+1}),
    compute D = ∅ and apply all deletion rules (a) through (g) -/
def computeDComplete (link : Link)
    (rigidPedigrees : List (RigidPedigree link.u.k))
    (fuel : ℕ := 100) : Finset Triple :=
  -- Apply basic rules (a) through (e)
  let D_basic :=
    ruleA link ∪
    ruleB link ∪
    ruleC link ∪
    ruleD link ∪
    ruleE link

  -- Apply cascading rule (f)
  let D_with_f := D_basic ∪ ruleF link D_basic fuel

  -- Apply rigid pedigree deletion rule (g)
  let D_final := D_with_f ∪ ruleG link D_with_f rigidPedigrees

  D_final

-- ============================================
-- LEGACY INTERFACE (for backward compatibility)
-- ============================================

/-- Legacy computeD for two triples (without full rule set) -/
def computeD_legacy (t1 t2 : Triple) : Finset Triple :=
  -- Construct a link from t1 and t2
  if h : t1.k + 1 = t2.k then
    let link : Link := { u := t1, v := t2, h_consecutive := h }
    ruleA link ∪ ruleB link ∪ ruleC link ∪ ruleD link ∪ ruleE link
  else
    ∅

/-- Maintain original computeD interface for compatibility -/
def computeD (t1 t2 : Triple) : Finset Triple :=
  computeD_legacy t1 t2

-- ============================================
-- NETWORK RESTRICTION
-- ============================================

/-- Restrict capacities by zeroing out triples in deletion set D -/
def restrictCapacities (caps : NodeCapacities) (D : Finset Triple) : NodeCapacities where
  caps t := if t ∈ D then 0 else caps.caps t
  nonneg t := by
    by_cases h : t ∈ D
    · simp only [h, ↓reduceIte]; norm_num
    · simp only [h, ↓reduceIte]; exact caps.nonneg t

/-- The restricted network N_{k-1}(L) has vertex set V(N_{k-1}) \ D -/
def restrictedVertexSet (k : ℕ) (D : Finset Triple) : Finset Triple :=
  ((Finset.range k).biUnion fun l => Delta l).filter fun t => t ∉ D

end Restriction

end MembershipProject.Core

-- ============================================
-- EXAMPLES AND TESTS
-- ============================================

section GeneratorExamples

open MembershipProject.Core

-- Example 1: G({2, 4, 6}) = {{1, 2, 4}, {2, 3, 4}}
example :
  let v := Triple.mk 2 4 6 (by omega) (by omega)
  let expected := {
    Triple.mk 1 2 4 (by omega) (by omega),
    Triple.mk 2 3 4 (by omega) (by omega)
  }
  generators v = expected := by
  sorry

-- Example 2: G({2, 3, 7}) = {{1, 2, 3}}
example :
  let v := Triple.mk 2 3 7 (by omega) (by omega)
  let expected := {Triple.mk 1 2 3 (by omega) (by omega)}
  generators v = expected := by
  sorry

-- Example 3: G({2, 4, 8}) = {{1, 2, 4}, {2, 3, 4}} (same as k=6)
example :
  let v1 := Triple.mk 2 4 6 (by omega) (by omega)
  let v2 := Triple.mk 2 4 8 (by omega) (by omega)
  generators v1 = generators v2 := by
  sorry

-- Example 4: G({1, 2, 3}) = ∅ (root has no generators)
example :
  let root := Triple.mk 1 2 3 (by omega) (by omega)
  generators root = ∅ := by
  sorry

-- Example 5: G({1, 3, 5}) with j=3 ≤ 3, so only {1,2,3}
example :
  let v := Triple.mk 1 3 5 (by omega) (by omega)
  let expected := {Triple.mk 1 2 3 (by omega) (by omega)}
  generators v = expected := by
  sorry

-- Example 6: G({3, 5, 7}) with j=5 > 3
-- Generators should be: {r, 3, 5} for r < 3 and {3, s, 5} for 3 < s < 5
-- = {{1, 3, 5}, {2, 3, 5}, {3, 4, 5}}
example :
  let v := Triple.mk 3 5 7 (by omega) (by omega)
  let expected := {
    Triple.mk 1 3 5 (by omega) (by omega),
    Triple.mk 2 3 5 (by omega) (by omega),
    Triple.mk 3 4 5 (by omega) (by omega)
  }
  generators v = expected := by
  sorry

end GeneratorExamples
