-- Core/SlackComputation.lean
import Mathlib.Data.Finset.Basic
import Mathlib.Tactic
import MembershipProject.Core.Basic
import MembershipProject.Core.MatrixOps
namespace MembershipProject.Core

open Nat

-- ============================================
-- RECURSIVE MIR STRUCTURE
-- ============================================

def initialSlack : SlackVector 3 := fun _ => (1 : Rat)

/-- Mathematical structure for Sparse Recursive MIR algorithm -/
structure MIRStructure (n : Nat) where
  P : ∀ (k : Nat), 3 ≤ k → k ≤ n → GenVector k
  nonneg : ∀ (k : Nat) (hk3 : 3 ≤ k) (hkn : k ≤ n) (v : GenVar k),
    P k hk3 hkn v ≥ (0 : Rat)

-- ... rest of your SlackComputation code ...

-- ============================================
-- SLACK COMPUTATION
-- ============================================

def computeSlackSparse (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk3 : 3 ≤ k) (hkn : k ≤ n) : SlackVector k :=
  if h : k = 3 then
    h ▸ initialSlack
  else
    have hk_prev : 3 ≤ k - 1 := by omega
    have hkn_prev : k - 1 ≤ n := by omega
    let U_prev := computeSlackSparse n mir (k - 1) hk_prev hkn_prev
    let A_k : SparseGenerationMatrix k := ⟨hk3⟩
    let P_k := mir.P k hk3 hkn
    fun e =>
      if hj : e.j < k - 1 then
        have hi_prev : e.i < k - 1 := by
          have h1 : e.i < e.j := e.hij
          have h2 : e.j < k - 1 := hj
          omega
        let e_prev : Edge (k - 1) := ⟨e.i, e.j, hi_prev, hj, e.hij⟩
        U_prev e_prev - sparseMatVecMul k A_k P_k e
      else
        (0 : Rat) - sparseMatVecMul k A_k P_k e
termination_by k
decreasing_by omega

-- ============================================
-- THEOREMS ABOUT SLACK COMPUTATION
-- ============================================

theorem computeSlackSparse_base_case (n : Nat) (mir : MIRStructure n)
    (hn : n ≥ 3) (e : Edge 3) :
    computeSlackSparse n mir 3 (by omega) (by omega) e = initialSlack e := by
  unfold computeSlackSparse
  simp

theorem computeSlackSparse_old_edge (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk : k ≥ 4) (hkn : k ≤ n) (e : Edge k)
    (h_old : e.j < k - 1) :
    computeSlackSparse n mir k (by omega) hkn e =
    computeSlackSparse n mir (k - 1) (by omega) (by omega : k - 1 ≤ n)
      ⟨e.i, e.j, by have h1 : e.i < e.j := e.hij; omega, h_old, e.hij⟩ -
    sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) e := by
  conv_lhs => unfold computeSlackSparse
  simp [show k ≠ 3 by omega, h_old]

theorem computeSlackSparse_new_edge (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk : k ≥ 4) (hkn : k ≤ n) (e : Edge k)
    (h_new : e.j = k - 1) :
    computeSlackSparse n mir k (by omega) hkn e =
    0 - sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) e := by
  unfold computeSlackSparse
  have h_not_old : ¬(e.j < k - 1) := by omega
  simp only [show k ≠ 3 by omega, ↓reduceDIte, h_not_old, ↓reduceDIte]

theorem computeSlackSparse_correct_base (n : Nat) (mir : MIRStructure n)
    (hn : n ≥ 3) :
    ∀ e : Edge 3, computeSlackSparse n mir 3 (by omega) (by omega : 3 ≤ n) e = initialSlack e := by
  intro e
  exact computeSlackSparse_base_case n mir hn e

theorem computeSlackSparse_correct_step_old (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk : k ≥ 4) (hkn : k ≤ n) (edge : Edge k) (h_old : edge.j < k - 1) :
    computeSlackSparse n mir k (by omega) hkn edge =
    computeSlackSparse n mir (k - 1) (by omega) (by omega : k - 1 ≤ n)
      ⟨edge.i, edge.j, by have h1 : edge.i < edge.j := edge.hij; omega, h_old, edge.hij⟩ -
    sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) edge :=
  computeSlackSparse_old_edge n mir k hk hkn edge h_old

theorem computeSlackSparse_correct_step_new (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk : k ≥ 4) (hkn : k ≤ n) (edge : Edge k) (h_new : edge.j ≥ k - 1) :
    computeSlackSparse n mir k (by omega) hkn edge =
    0 - sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) edge := by
  have h_eq : edge.j = k - 1 := by
    have hj : edge.j < k := edge.hj
    omega
  exact computeSlackSparse_new_edge n mir k hk hkn edge h_eq

theorem computeSlackSparse_correct_step (n : Nat) (mir : MIRStructure n)
    (k : Nat) (hk : k ≥ 4) (hkn : k ≤ n) (edge : Edge k) :
    if h : edge.j < k - 1 then
      computeSlackSparse n mir k (by omega) hkn edge =
      computeSlackSparse n mir (k - 1) (by omega) (by omega : k - 1 ≤ n)
        ⟨edge.i, edge.j, by have h1 : edge.i < edge.j := edge.hij; omega, h, edge.hij⟩ -
      sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) edge
    else
      computeSlackSparse n mir k (by omega) hkn edge =
      0 - sparseMatVecMul k ⟨by omega⟩ (mir.P k (by omega) hkn) edge := by
  split
  case isTrue h_old =>
    exact computeSlackSparse_correct_step_old n mir k hk hkn edge h_old
  case isFalse h_new =>
    have h_ge : edge.j ≥ k - 1 := by omega
    exact computeSlackSparse_correct_step_new n mir k hk hkn edge h_ge

end MembershipProject.Core
