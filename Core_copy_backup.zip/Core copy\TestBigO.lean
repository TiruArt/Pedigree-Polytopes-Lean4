import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Order.Partition.Finpartition

open Finset

variable {α : Type*} [DecidableEq α]

/-- A probability distribution over a finite set -/
structure ProbDist (D : Finset α) where
  prob : α → ℕ
  sum_eq_card : ∑ a ∈ D, prob a = D.card

/-- Probability of a subset -/
def probSubset {D : Finset α} (p : ProbDist D) (S : Finset α) : ℕ :=
  ∑ a ∈ (S ∩ D), p.prob a

/-- Flow for the FAT problem -/
def flowFAT {D : Finset α} (p : ProbDist D)
    (_D₁ _D₂ : Finpartition D) (S T : Finset α) : ℕ :=
  probSubset p (S ∩ T)

/-- Helper lemma: summing over partition intersections -/
lemma sum_partition_inter {D : Finset α} (p : ProbDist D)
    (D_part : Finpartition D) (S : Finset α) (hS : S ⊆ D) :
    ∑ T ∈ D_part.parts, probSubset p (S ∩ T) = probSubset p S := by
  unfold probSubset
  have h_inter : S ∩ D = S := inter_eq_left.mpr hS
  rw [← h_inter]
  -- Simplify S ∩ D ∩ D = S ∩ D
  simp only [inter_assoc, inter_self]
  rw [← sum_biUnion]
  · congr 1
    ext a
    simp only [mem_biUnion, mem_inter]
    constructor
    · intro ⟨T, _hT, haS, haD, haT, _⟩
      exact ⟨haS, haD⟩
    · intro ⟨haS, haD⟩
      obtain ⟨T, hT, haT⟩ := D_part.exists_mem haD
      have hTD : T ⊆ D := by
        intro x hx
        have : x ∈ D_part.supₛ := D_part.supₛ_parts ▸ mem_biUnion.mpr ⟨T, hT, hx⟩
        exact this
      exact ⟨T, hT, haS, haD, haT, hTD haT⟩
  · intro T₁ hT₁ T₂ hT₂ hne
    simp only [Function.onFun, disjoint_iff_inter_eq_empty]
    ext a
    simp only [mem_inter, mem_empty, iff_false]
    tauto

/-- Main feasibility theorem -/
theorem flowFAT_feasible {D : Finset α} (p : ProbDist D)
    (D₁ D₂ : Finpartition D) :
    (∀ S, S ∈ D₁.parts → ∑ T ∈ D₂.parts, flowFAT p D₁ D₂ S T = probSubset p S) ∧
    (∀ T, T ∈ D₂.parts → ∑ S ∈ D₁.parts, flowFAT p D₁ D₂ S T = probSubset p T) := by
  constructor
  · -- Supply constraint
    intro S hS
    unfold flowFAT
    have hS_sub : S ⊆ D := by
      intro x hx
      have : x ∈ D₁.supₛ := D₁.supₛ_parts ▸ mem_biUnion.mpr ⟨S, hS, hx⟩
      exact this
    exact sum_partition_inter p D₂ S hS_sub
  · -- Demand constraint
    intro T hT
    unfold flowFAT
    have hT_sub : T ⊆ D := by
      intro x hx
      have : x ∈ D₂.supₛ := D₂.supₛ_parts ▸ mem_biUnion.mpr ⟨T, hT, hx⟩
      exact this
    conv_lhs =>
      arg 2
      ext S
      rw [inter_comm]
    exact sum_partition_inter p D₁ T hT_sub
