-- Core/Types.lean
import Mathlib.Data.Finset.Basic
import Mathlib.Tactic

namespace MembershipProject.Core

-- ============================================
-- BASIC GRAPH STRUCTURES
-- ============================================

/-- A node (i,j,k) in the pedigree graph -/
structure Node where
  i : Nat
  j : Nat
  k : Nat
  deriving Repr, DecidableEq, BEq

-- ============================================
-- SPARSE DATA ENTRY
-- ============================================

/-- Single sparse data entry: (i,j,k) → x_ijk with constraints -/
structure SparseEntry (n : ℕ) where
  i : Fin n
  j : Fin n
  k : Nat
  value : Rat
  h_order : i < j
  h_i_bound : 1 ≤ i.val
  h_j_less_k : j.val < k
  h_k_bound : k ≤ n
  h_nonneg : value ≥ 0  -- Added non-negativity constraint
  deriving Repr

-- ============================================
-- PARSED DATA STRUCTURE (from files)
-- ============================================

/-- Sparse recursive MIR data structure (for parsing input files) -/
structure ParsedMIRData (n : ℕ) where
  prob_name : String
  data : Array (SparseEntry n)
  pmi_status : Option Bool
  deriving Repr

end MembershipProject.Core
